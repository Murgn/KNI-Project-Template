using System;
using System.Reflection;
using System.Text.RegularExpressions;
using Engine.Screens;
using ImGuiNET;
using Microsoft.Xna.Framework;
using Vector4 = System.Numerics.Vector4;

namespace Engine.Debugging;

public static class Editor
{
    internal const int OFFSET_FROM_START_X = 150;
    internal const int ITEM_WIDTH = 75;
    
    private static GameObject selectedObject;
    
    public static void DrawDebugEditor(this GameObjectScreen screen)
    {
        if (ImGui.Begin(FormatName(screen.Name)))
        {
            float width = ImGui.GetContentRegionAvail().X;
            float height = ImGui.GetContentRegionAvail().Y;
                
            ImGui.BeginChild("Hierarchy", new System.Numerics.Vector2(width * 0.3f, height * 0.65f), ImGuiChildFlags.Border);
            ImGui.Text("Hierarchy");
            ImGui.Separator();
                
            foreach (var obj in screen.GameObjects)
            {
                if (ImGui.Selectable(obj.Name, selectedObject == obj))
                {
                    selectedObject = obj;
                }
            }

            ImGui.EndChild();
            ImGui.SameLine();
                
            ImGui.BeginChild("Inspector", new System.Numerics.Vector2(0, height * 0.65f), ImGuiChildFlags.Border);
            ImGui.Text("Inspector");
            ImGui.Separator();
                
            if (selectedObject != null)
            {
                ImGui.BeginChild("Transform", new System.Numerics.Vector2(0, 0), ImGuiChildFlags.Border | ImGuiChildFlags.AutoResizeY);
                ImGui.Text("Transform");
                ImGui.Spacing();
                
                Vector2 position = selectedObject.Transform.Position;
                if (DrawVector2("Position", ref position))
                    selectedObject.Transform.Position = position;
                
                float rotation = selectedObject.Transform.Rotation;
                if(DrawFloat("Rotation", ref rotation))
                    selectedObject.Transform.Rotation = rotation;
                
                Vector2 scale = selectedObject.Transform.Scale;
                if (DrawVector2("Scale", ref scale))
                    selectedObject.Transform.Scale = scale;
                
                ImGui.EndChild();
                
                foreach (var script in selectedObject.scripts)
                {
                    ImGui.BeginChild(script.ToString(), new System.Numerics.Vector2(0, 0), ImGuiChildFlags.Border | ImGuiChildFlags.AutoResizeY);
                    ImGui.Text(FormatName(script.GetType().Name));
                    
                    bool enabled = script.Enabled;
                    float checkboxWidth = ImGui.GetFrameHeight();
                    float rightX = ImGui.GetWindowSize().X - ImGui.GetStyle().WindowPadding.X - checkboxWidth;
                    ImGui.SameLine(rightX);

                    if (ImGui.Checkbox("##Enabled", ref enabled))
                        script.Enabled = enabled;
                    
                    ImGui.Spacing();

                    foreach (var member in script.GetType().GetMembers(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance))
                    {
                        if (member is not FieldInfo && member is not PropertyInfo)
                            continue;

                        if (member.GetCustomAttribute<DontInspectAttribute>() != null)
                            continue;
                        
                        if (member is PropertyInfo enabledProperty && enabledProperty.DeclaringType == typeof(Script) && enabledProperty.Name == nameof(Script.Enabled))
                            continue;
                        
                        bool isPublic = member switch
                        {
                            FieldInfo field => field.IsPublic,

                            PropertyInfo property =>
                                property.GetMethod?.IsPublic == true ||
                                property.SetMethod?.IsPublic == true,

                            _ => false
                        };

                        bool hasInspect = member.GetCustomAttribute<InspectAttribute>() != null;
                        bool hasReadOnly = member.GetCustomAttribute<ReadOnlyAttribute>() != null;

                        
                        if (!isPublic && !hasInspect && !hasReadOnly)
                            continue;

                        DrawMember(script, member);
                    }
                    
                    ImGui.EndChild();
                }
            }

                
            ImGui.EndChild();
            
            ImGui.BeginChild("Console", new System.Numerics.Vector2(0, height * 0.35f), ImGuiChildFlags.AutoResizeY | ImGuiChildFlags.Border);
            ImGui.Text("Console");
            ImGui.Separator();
            
            ImGui.BeginChild("Console Messages", new System.Numerics.Vector2(0, 0), ImGuiChildFlags.AlwaysAutoResize);

            foreach (var log in Debug.ConsoleLogs)
            {
                ImGui.PushStyleColor(ImGuiCol.Text, ConsoleWriter.GetImGuiColor(log.Color));
                ImGui.TextUnformatted(log.Text);
                ImGui.PopStyleColor();
            }
            
            if (ImGui.GetScrollY() >= ImGui.GetScrollMaxY())
                ImGui.SetScrollHereY(1.0f);
            ImGui.EndChild();
            

            ImGui.EndChild();
            
            ImGui.End();
        }
    }
    
    public static bool DrawVector2(string label, ref Vector2 value, bool readOnly = false)
    {
        bool changed = false;

        ImGui.Text(label);
        
        float labelWidth = ImGui.CalcTextSize(label).X;
        float offset = MathF.Max(OFFSET_FROM_START_X, ImGui.GetCursorPosX() + labelWidth + ImGui.GetStyle().ItemSpacing.X);
        ImGui.SameLine(offset);

        float x = value.X;
        float y = value.Y;
        
        if (readOnly)
            ImGui.BeginDisabled();

        ImGui.SetNextItemWidth(ITEM_WIDTH);
        if (ImGui.DragFloat("X##" + label, ref x, 1.0f, 0.0f, 0.0f, "%.2f"))
            changed = true;

        ImGui.SameLine();

        ImGui.SetNextItemWidth(ITEM_WIDTH);
        if (ImGui.DragFloat("Y##" + label, ref y, 1.0f, 0.0f, 0.0f, "%.2f"))
            changed = true;

        value.X = x;
        value.Y = y;

        if (readOnly)
            ImGui.EndDisabled();
        
        return changed;
    }
    
    public static bool DrawFloat(string label, ref float value, bool readOnly = false)
    {
        bool changed = false;
        
        ImGui.Text(label);
        
        float labelWidth = ImGui.CalcTextSize(label).X;
        float offset = MathF.Max(OFFSET_FROM_START_X, ImGui.GetCursorPosX() + labelWidth + ImGui.GetStyle().ItemSpacing.X);
        ImGui.SameLine(offset);
        
        if (readOnly)
            ImGui.BeginDisabled();
        
        ImGui.SetNextItemWidth(ITEM_WIDTH);
        if (ImGui.DragFloat("##" + label, ref value, 1.0f, 0.0f, 0.0f, "%.2f"))
            changed = true;

        if (readOnly)
            ImGui.EndDisabled();
        
        return changed;
    }
    
    public static bool DrawInt(string label, ref int value, bool readOnly = false)
    {
        bool changed = false;
        
        ImGui.Text(label);
        
        float labelWidth = ImGui.CalcTextSize(label).X;
        float offset = MathF.Max(OFFSET_FROM_START_X, ImGui.GetCursorPosX() + labelWidth + ImGui.GetStyle().ItemSpacing.X);
        ImGui.SameLine(offset);
        
        if (readOnly)
            ImGui.BeginDisabled();
        
        ImGui.SetNextItemWidth(ITEM_WIDTH);
        if (ImGui.DragInt("##" + label, ref value))
            changed = true;

        if (readOnly)
            ImGui.EndDisabled();
        
        return changed;
    }
    
    public static bool DrawCheckbox(string label, ref bool value, bool readOnly = false)
    {
        bool changed = false;
        
        ImGui.Text(label);
        
        float labelWidth = ImGui.CalcTextSize(label).X;
        float offset = MathF.Max(OFFSET_FROM_START_X, ImGui.GetCursorPosX() + labelWidth + ImGui.GetStyle().ItemSpacing.X);
        ImGui.SameLine(offset);
        
        if (readOnly)
            ImGui.BeginDisabled();
        
        ImGui.SetNextItemWidth(ITEM_WIDTH);
        if (ImGui.Checkbox("##" + label, ref value))
            changed = true;

        if (readOnly)
            ImGui.EndDisabled();
        
        return changed;
    }
    
    public static bool DrawString(string label, ref string value, bool readOnly = false)
    {
        bool changed = false;
        
        if (readOnly)
            ImGui.BeginDisabled();

        ImGui.Text(label);
        
        float labelWidth = ImGui.CalcTextSize(label).X;
        float offset = MathF.Max(OFFSET_FROM_START_X, ImGui.GetCursorPosX() + labelWidth + ImGui.GetStyle().ItemSpacing.X);
        ImGui.SameLine(offset);
        
        ImGui.SetNextItemWidth(ITEM_WIDTH);
        if (ImGui.InputText("##" + label, ref value, 256))
            changed = true;

        if (readOnly)
            ImGui.EndDisabled();
        
        return changed;
    }
    
    public static bool DrawColor(string label, ref Color value, bool readOnly = false)
    {
        bool changed = false;
        
        if (readOnly)
            ImGui.BeginDisabled();

        ImGui.Text(label);
        
        float labelWidth = ImGui.CalcTextSize(label).X;
        float offset = MathF.Max(OFFSET_FROM_START_X, ImGui.GetCursorPosX() + labelWidth + ImGui.GetStyle().ItemSpacing.X);
        ImGui.SameLine(offset);
        
        ImGui.SetNextItemWidth(ITEM_WIDTH * 2.0f);
        Vector4 col = new Vector4(value.R / 255.0f, value.G / 255.0f, value.B / 255.0f, value.A / 255.0f);
        if (ImGui.ColorEdit4("##" + label, ref col))
        {
            changed = true;
            value = new Color(col.X, col.Y, col.Z, col.W);
        }

        if (readOnly)
            ImGui.EndDisabled();
        
        return changed;
    }
    
    private static void DrawMember(object script, MemberInfo member)
    {
        object? value = GetMemberValue(script, member);
        
        bool readOnly =
            member is PropertyInfo property && property.SetMethod == null ||
            member.GetCustomAttribute<ReadOnlyAttribute>() != null;
        
        switch (GetMemberType(member))
        {
            case { } t when t == typeof(int):
                int intValue = (int)(value ?? 0);
                
                if (DrawInt(member.Name, ref intValue, readOnly) && !readOnly)
                    SetMemberValue(script, member, intValue);
                break;

            case { } t when t == typeof(float):
                float floatValue = (float)(value ?? 0.0f);
                
                if (DrawFloat(member.Name, ref floatValue, readOnly) && !readOnly)
                    SetMemberValue(script, member, floatValue);     
                break;

            case { } t when t == typeof(bool):
                bool boolValue = (bool)(value ?? false);
                
                if (DrawCheckbox(member.Name, ref boolValue, readOnly) && !readOnly)
                    SetMemberValue(script, member, boolValue);
                break;

            case { } t when t == typeof(string):
                string stringValue = (string)(value ?? "");
                
                if (DrawString(member.Name, ref stringValue, readOnly) && !readOnly)
                    SetMemberValue(script, member, stringValue);
                break;
            
            case { } t when t == typeof(Color):
                Color colorValue = (Color)(value ?? Color.White);
                
                if (DrawColor(member.Name, ref colorValue, readOnly) && !readOnly)
                    SetMemberValue(script, member, colorValue);
                break;

        }
    }
    
    private static Type GetMemberType(MemberInfo member)
    {
        return member switch
        {
            FieldInfo field => field.FieldType,
            PropertyInfo property => property.PropertyType,
            _ => throw new ArgumentException("Unsupported member type")
        };
    }
    
    private static object? GetMemberValue(object instance, MemberInfo member)
    {
        return member switch
        {
            FieldInfo field => field.GetValue(instance),
            PropertyInfo property => property.GetValue(instance),
            _ => null
        };
    }
    
    private static void SetMemberValue(object script, MemberInfo member, object value)
    {
        switch (member)
        {
            case FieldInfo field:
                field.SetValue(script, value);
                break;

            case PropertyInfo property:
                if (property.SetMethod != null)
                    property.SetValue(script, value);
                break;
        }
    }
    
    public static string FormatName(string name)
    {
        return Regex.Replace(
            name,
            "(?<!^)([A-Z])|(?<=[A-Z])([A-Z])(?=[a-z])",
            " $1$2"
        );
    }
}